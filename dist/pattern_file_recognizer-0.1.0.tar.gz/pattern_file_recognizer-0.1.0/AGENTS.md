# AGENTS.md

## 1. Requirements Format

- REQ-1: Requirement identifiers MUST follow the pattern "{prefix}-{ordinal}".
- REQ-2: Requirement prefixes MUST concisely indicate the concern domain.
- REQ-3: Requirement text MUST use RFC 2119 modal verbs.
- REQ-4: Requirements MUST be short, concise, and unambiguous.
- REQ-5: Bulleted lists without requirement identifiers MUST NOT be used.
- REQ-6: These meta‑requirements themselves MUST follow all requirements defined in this section.

## 2. LLM Agentic Behavior & Anti‑Patterns

- AGENT-1: Agents MUST NOT emit TODOs, placeholders, or incomplete code.
- AGENT-2: All generated code MUST be production quality and free of missing logic.
- AGENT-3: Agents MUST NOT make assumptions; all gaps MUST be surfaced explicitly.
- AGENT-4: Conflicts or ambiguities in requirements MUST be escalated and resolved prior to execution.
- AGENT-5: Agents MUST adhere to deterministic, spec‑driven behavior.
- AGENT-6: Any generated documentation such as Markdown plans MUST be stored in the `docs` directory.

## 3. Software Engineering Best Practices

- SWENG-1: Systems MUST follow the Single Responsibility Principle.
- SWENG-2: Systems MUST apply Design by Contract, with explicit preconditions and postconditions.
- SWENG-3: Systems SHOULD use a Functional Core with an Imperative Shell.
- SWENG-4: State mutation MUST be isolated at the system boundaries.

## 4. Python Development Standards

- PY-1: Python development MUST use the Astral toolchain (uv, ruff, ty).
- PY-2: pip MUST NOT be used under any circumstances.
- PY-3: Pydantic MUST be used for data modeling and validation.
- PY-4: Abstract Base Classes (ABCs) MUST be used for interface and contract definition.
- PY-5: Test suites MUST use state‑of‑the‑art testing tools appropriate for Python and MUST enforce high coverage.
- PY-6: Shell commands which use the python interpreter MUST use the venv created by uv.

