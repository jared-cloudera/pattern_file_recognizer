#!/usr/bin/env python3
"""
Utility script to analyze shared aliases in customer data.

This script reads the customers.parquet file, extracts aliases for each customer,
and identifies aliases that are shared by multiple customers. The output is a CSV
report with the alias name and the count of customers sharing that alias.
"""

import json
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd


def load_customer_data(parquet_path: Path) -> pd.DataFrame:
    """Load customer data from parquet file."""
    if not parquet_path.exists():
        raise FileNotFoundError(f"Customer data not found at {parquet_path}")
    return pd.read_parquet(parquet_path)


def parse_aliases(aliases_value) -> list[str]:
    """
    Parse aliases from the dataframe cell.
    
    Handles both Python lists and JSON strings.
    """
    if pd.isna(aliases_value):
        return []
    
    if isinstance(aliases_value, list):
        return aliases_value
    
    if isinstance(aliases_value, str):
        try:
            aliases_list = json.loads(aliases_value)
            if isinstance(aliases_list, list):
                return aliases_list
        except json.JSONDecodeError:
            pass
    
    return []


def build_alias_to_customers_mapping(df: pd.DataFrame) -> dict[str, set[str]]:
    """
    Build a mapping from each alias to the set of customer names that have it.
    
    Args:
        df: DataFrame with 'name' and 'aliases' columns
        
    Returns:
        Dictionary mapping alias -> set of customer names
    """
    alias_to_customers = defaultdict(set)
    
    for _, row in df.iterrows():
        customer_name = row.get('name')
        if pd.isna(customer_name):
            continue
            
        aliases = parse_aliases(row.get('aliases'))
        
        for alias in aliases:
            if alias:  # Skip empty strings
                alias_to_customers[alias].add(customer_name)
    
    return alias_to_customers


def filter_shared_aliases(alias_to_customers: dict[str, set[str]]) -> dict[str, int]:
    """
    Filter to only aliases shared by more than one customer.
    
    Args:
        alias_to_customers: Mapping of alias -> set of customer names
        
    Returns:
        Dictionary mapping alias -> count of customers (only where count > 1)
    """
    shared_aliases = {}
    
    for alias, customers in alias_to_customers.items():
        count = len(customers)
        if count > 1:
            shared_aliases[alias] = count
    
    return shared_aliases


def save_report(shared_aliases: dict[str, int], output_path: Path) -> None:
    """
    Save the shared aliases report as a CSV file.
    
    Args:
        shared_aliases: Dictionary mapping alias -> count
        output_path: Path where the CSV should be saved
    """
    # Create DataFrame and sort by count (descending) then by alias name
    df = pd.DataFrame([
        {'alias': alias, 'count': count}
        for alias, count in shared_aliases.items()
    ])
    
    if not df.empty:
        df = df.sort_values(by=['count', 'alias'], ascending=[False, True])
    
    df.to_csv(output_path, index=False)


def main():
    """Main execution function."""
    # Determine the parquet file path (relative to script location)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    parquet_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    # Output path (current working directory)
    output_path = Path.cwd() / "common_aliases_report.csv"
    
    print(f"Loading customer data from: {parquet_path}")
    df = load_customer_data(parquet_path)
    print(f"Loaded {len(df)} customer records")
    
    print("Building alias-to-customers mapping...")
    alias_to_customers = build_alias_to_customers_mapping(df)
    print(f"Found {len(alias_to_customers)} unique aliases")
    
    print("Filtering for shared aliases...")
    shared_aliases = filter_shared_aliases(alias_to_customers)
    print(f"Found {len(shared_aliases)} aliases shared by multiple customers")
    
    print(f"Saving report to: {output_path}")
    save_report(shared_aliases, output_path)
    print("Report generation complete!")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

