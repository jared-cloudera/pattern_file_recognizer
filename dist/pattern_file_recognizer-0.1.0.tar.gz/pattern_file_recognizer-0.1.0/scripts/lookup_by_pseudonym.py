#!/usr/bin/env python3
"""
Utility script to lookup customer name by pseudonym.

This script takes a pseudonym as input and returns the corresponding customer name.

Usage:
    python scripts/lookup_by_pseudonym.py "Customer_123"
    python scripts/lookup_by_pseudonym.py "Customer_123" --parquet-path /path/to/data.parquet
"""

import argparse
import sys
from pathlib import Path

import pandas as pd


def find_customer_by_pseudonym(
    df: pd.DataFrame, 
    target_pseudonym: str
) -> list[str]:
    """
    Find customer name that has the specified pseudonym.
    
    Args:
        df: DataFrame with 'name' and 'pseudonym' columns
        target_pseudonym: The pseudonym to search for
        
    Returns:
        List of customer names that have the specified pseudonym (should be 0 or 1)
    """
    matching_customers = []
    
    # Ensure pseudonym column exists
    if 'pseudonym' not in df.columns:
        return []
        
    # precise match
    matches = df[df['pseudonym'] == target_pseudonym]
    
    if not matches.empty:
        matching_customers = matches['name'].tolist()
    
    return matching_customers


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Lookup customer name by pseudonym",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "Customer_A"
        """
    )
    parser.add_argument(
        "pseudonym",
        help="The pseudonym to search for"
    )
    parser.add_argument(
        "--parquet-path",
        type=Path,
        help="Path to customers.parquet file (default: auto-detect from script location)"
    )
    
    args = parser.parse_args()
    
    # Determine the parquet file path
    if args.parquet_path:
        parquet_path = args.parquet_path
    else:
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        parquet_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    if not parquet_path.exists():
        print(f"Error: Customer data not found at {parquet_path}", file=sys.stderr)
        return 1
    
    # Load data
    try:
        df = pd.read_parquet(parquet_path)
    except Exception as e:
        print(f"Error reading parquet file: {e}", file=sys.stderr)
        return 1
    
    # Find matching customers
    matching_customers = find_customer_by_pseudonym(
        df, 
        args.pseudonym
    )
    
    # Display results
    if matching_customers:
        # Assuming pseudonym is unique, but printing all just in case
        for customer in matching_customers:
            print(customer)
    else:
        print(f"No customer found with pseudonym '{args.pseudonym}'", file=sys.stderr)
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

