#!/usr/bin/env python3
"""
Utility script to remove an alias from a customer's aliases list.

This script finds a customer by name and removes a specified alias from their
aliases list if it exists. The updated data is saved to a new parquet file.

Usage:
    python scripts/remove_alias.py "IBM" "Big Blue"
    python scripts/remove_alias.py "IBM" "Big Blue" --input custom.parquet --output updated.parquet
    python scripts/remove_alias.py "IBM" "Big Blue" --dry-run
"""

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


def parse_aliases(aliases_value) -> list[str]:
    """
    Parse aliases from the dataframe cell.
    
    Handles both Python lists and JSON strings.
    """
    # Check if it's already a list first (before pd.isna which fails on lists)
    if isinstance(aliases_value, list):
        return aliases_value
    
    if pd.isna(aliases_value):
        return []
    
    if isinstance(aliases_value, str):
        try:
            aliases_list = json.loads(aliases_value)
            if isinstance(aliases_list, list):
                return aliases_list
        except json.JSONDecodeError:
            pass
    
    return []


def remove_alias_from_customer(
    df: pd.DataFrame,
    customer_name: str,
    alias_to_remove: str,
    case_sensitive: bool = False,
    dry_run: bool = False
) -> tuple[pd.DataFrame, dict]:
    """
    Remove an alias from a customer's aliases list.
    
    Args:
        df: DataFrame with customer data
        customer_name: The name of the customer
        alias_to_remove: The alias to remove
        case_sensitive: Whether to perform case-sensitive matching
        dry_run: If True, only report what would be changed without modifying data
        
    Returns:
        Tuple of (modified_dataframe, result_dict)
    """
    # Work with a copy to avoid modifying original
    df = df.copy()
    
    result = {
        'found_customer': False,
        'found_alias': False,
        'removed': False,
        'original_alias_count': 0,
        'final_alias_count': 0,
        'customer_name': customer_name,
        'alias': alias_to_remove
    }
    
    # Find customer
    customer_mask = df['name'] == customer_name
    if not customer_mask.any():
        print(f"ERROR: Customer '{customer_name}' not found.")
        return df, result
    
    result['found_customer'] = True
    customer_idx = df[customer_mask].index[0]
    
    # Get current aliases
    aliases = parse_aliases(df.at[customer_idx, 'aliases'])
    result['original_alias_count'] = len(aliases)
    
    print(f"Customer: {customer_name}")
    print(f"Current aliases: {len(aliases)}")
    
    # Find the alias to remove (with case sensitivity option)
    alias_found_idx = None
    actual_alias = None
    
    for idx, alias in enumerate(aliases):
        if case_sensitive:
            if alias == alias_to_remove:
                alias_found_idx = idx
                actual_alias = alias
                break
        else:
            if alias.lower() == alias_to_remove.lower():
                alias_found_idx = idx
                actual_alias = alias
                break
    
    if alias_found_idx is None:
        print(f"Alias '{alias_to_remove}' not found in customer's aliases list.")
        return df, result
    
    result['found_alias'] = True
    
    # Remove the alias
    if dry_run:
        print(f"\n[DRY RUN] Would remove alias: '{actual_alias}'")
        result['final_alias_count'] = len(aliases) - 1
    else:
        aliases.pop(alias_found_idx)
        df.at[customer_idx, 'aliases'] = aliases
        result['removed'] = True
        result['final_alias_count'] = len(aliases)
        print(f"Removed alias: '{actual_alias}'")
        print(f"New alias count: {len(aliases)}")
    
    return df, result


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Remove an alias from a customer's aliases list",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "IBM" "Big Blue"
  %(prog)s "IBM" "Big Blue" --case-sensitive
  %(prog)s "IBM" "Big Blue" --dry-run
  %(prog)s "IBM" "Big Blue" --output updated_customers.parquet
        """
    )
    parser.add_argument(
        "customer_name",
        help="The name of the customer"
    )
    parser.add_argument(
        "alias",
        help="The alias to remove"
    )
    parser.add_argument(
        "--input",
        type=Path,
        help="Path to input customers.parquet file (default: auto-detect)"
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Path to output parquet file (default: customers_updated.parquet in CWD)"
    )
    parser.add_argument(
        "--case-sensitive",
        action="store_true",
        help="Perform case-sensitive alias matching (default: case-insensitive)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be changed without modifying data"
    )
    
    args = parser.parse_args()
    
    # Determine input path
    if args.input:
        input_path = args.input
    else:
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        input_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    if not input_path.exists():
        print(f"Error: Input file not found at {input_path}", file=sys.stderr)
        return 1
    
    # Determine output path
    if args.output:
        output_path = args.output
    else:
        output_path = Path.cwd() / "customers_updated.parquet"
    
    print(f"Loading customer data from: {input_path}")
    df = pd.read_parquet(input_path)
    print(f"Loaded {len(df)} customer records\n")
    
    if args.dry_run:
        print("=== DRY RUN MODE - No changes will be made ===\n")
    
    # Remove the alias
    df_result, result = remove_alias_from_customer(
        df,
        args.customer_name,
        args.alias,
        case_sensitive=args.case_sensitive,
        dry_run=args.dry_run
    )
    
    # Check if operation was successful
    if not result['found_customer']:
        return 1
    
    if not result['found_alias']:
        return 1
    
    if args.dry_run:
        print("\n=== DRY RUN COMPLETE - No files written ===")
        return 0
    
    # Save result
    print(f"\nSaving updated data to: {output_path}")
    
    # Convert aliases lists to JSON strings for parquet compatibility
    df_result['aliases'] = df_result['aliases'].apply(
        lambda x: json.dumps(x) if isinstance(x, list) else x
    )
    
    df_result.to_parquet(output_path, index=False)
    print("Done!")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

