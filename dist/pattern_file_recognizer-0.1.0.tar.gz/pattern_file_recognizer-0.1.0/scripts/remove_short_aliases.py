#!/usr/bin/env python3
"""
Utility script to remove short aliases and numeric-only aliases from all customers.

This script scans all customers and removes any alias that is:
1. 1 or 2 characters long
2. Consists only of numbers (integers or decimals)

The updated data is saved to a new parquet file.

Usage:
    python scripts/remove_short_aliases.py
    python scripts/remove_short_aliases.py --dry-run
    python scripts/remove_short_aliases.py --input custom.parquet --output updated.parquet
"""

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


def is_numeric_only(s: str) -> bool:
    """
    Check if a string consists only of numbers (integers or decimals).
    
    Examples of numeric-only strings:
    - "123"
    - "12.34"
    - "0.5"
    
    Examples of non-numeric strings:
    - "12a"
    - "1.2.3" (though this might be considered a version number, simple decimal check is usually enough)
    - "a12"
    """
    # Simple regex for integer or decimal number
    # Matches: optional sign, digits, optional dot, optional digits
    # But usually aliases are just positive numbers in this context. 
    # Let's stick to standard float representation without exponent for now as per requirement "strings of numbers, both integers and with decimals"
    
    # Check if it looks like a float or int
    try:
        float(s)
        return True
    except ValueError:
        return False


def parse_aliases(aliases_value) -> list[str]:
    """
    Parse aliases from the dataframe cell.
    
    Handles both Python lists and JSON strings.
    """
    # Check if it's already a list first (before pd.isna which fails on lists)
    if isinstance(aliases_value, list):
        return aliases_value
    
    if pd.isna(aliases_value):
        return []
    
    if isinstance(aliases_value, str):
        try:
            aliases_list = json.loads(aliases_value)
            if isinstance(aliases_list, list):
                return aliases_list
        except json.JSONDecodeError:
            pass
    
    return []


def remove_short_aliases(
    df: pd.DataFrame,
    dry_run: bool = False
) -> tuple[pd.DataFrame, dict]:
    """
    Remove aliases with length <= 2 or numeric-only aliases from all customers.
    
    Args:
        df: DataFrame with customer data
        dry_run: If True, only report what would be changed without modifying data
        
    Returns:
        Tuple of (modified_dataframe, stats_dict)
    """
    # Work with a copy to avoid modifying original
    df = df.copy()
    
    stats = {
        'customers_checked': 0,
        'customers_modified': 0,
        'aliases_removed': 0,
        'removed_details': []  # List of dicts with customer and removed alias
    }
    
    for idx, row in df.iterrows():
        stats['customers_checked'] += 1
        
        customer_name = row.get('name', 'Unknown')
        aliases = parse_aliases(row.get('aliases'))
        
        if not aliases:
            continue
            
        original_count = len(aliases)
        
        # Filter out short aliases and numeric-only aliases
        # Keep aliases strictly longer than 2 characters AND not numeric-only
        kept_aliases = []
        removed_aliases = []
        
        for alias in aliases:
            # Check for removal conditions
            is_short = len(alias) <= 2
            is_numeric = is_numeric_only(alias)
            
            if is_short or is_numeric:
                removed_aliases.append(alias)
            else:
                kept_aliases.append(alias)
        
        if len(kept_aliases) < original_count:
            stats['customers_modified'] += 1
            stats['aliases_removed'] += len(removed_aliases)
            
            for removed in removed_aliases:
                stats['removed_details'].append({
                    'customer': customer_name,
                    'alias': removed
                })
            
            if not dry_run:
                df.at[idx, 'aliases'] = kept_aliases
    
    return df, stats


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Remove short aliases (length <= 2) and numeric-only aliases from all customers",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --dry-run
  %(prog)s --output cleaned_customers.parquet
        """
    )
    parser.add_argument(
        "--input",
        type=Path,
        help="Path to input customers.parquet file (default: auto-detect)"
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Path to output parquet file (default: customers_cleaned.parquet in CWD)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be changed without modifying data"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print details of every removed alias"
    )
    
    args = parser.parse_args()
    
    # Determine input path
    if args.input:
        input_path = args.input
    else:
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        input_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    if not input_path.exists():
        print(f"Error: Input file not found at {input_path}", file=sys.stderr)
        return 1
    
    # Determine output path
    if args.output:
        output_path = args.output
    else:
        output_path = Path.cwd() / "customers_cleaned.parquet"
    
    print(f"Loading customer data from: {input_path}")
    try:
        df = pd.read_parquet(input_path)
    except Exception as e:
        print(f"Error reading parquet file: {e}", file=sys.stderr)
        return 1
        
    print(f"Loaded {len(df)} customer records\n")
    
    if args.dry_run:
        print("=== DRY RUN MODE - No changes will be made ===\n")
    
    # Remove short aliases
    df_result, stats = remove_short_aliases(
        df,
        dry_run=args.dry_run
    )
    
    # Report results
    print(f"Checked {stats['customers_checked']} customers.")
    print(f"Found {stats['aliases_removed']} aliases to remove across {stats['customers_modified']} customers.")
    
    if args.verbose and stats['removed_details']:
        print("\nDetails of removed aliases:")
        for detail in stats['removed_details']:
            print(f"  - Customer: {detail['customer']}, Removed Alias: '{detail['alias']}'")
    
    if stats['aliases_removed'] == 0:
        print("\nNo short aliases found. No changes needed.")
        return 0
        
    if args.dry_run:
        print("\n=== DRY RUN COMPLETE - No files written ===")
        return 0
    
    # Save result
    print(f"\nSaving updated data to: {output_path}")
    
    # Convert aliases lists to JSON strings for parquet compatibility if needed, 
    # but pandas to_parquet handles lists fine usually. 
    # However, to maintain consistency with other scripts that might expect JSON strings or lists:
    # The original remove_alias.py does:
    # df_result['aliases'] = df_result['aliases'].apply(
    #    lambda x: json.dumps(x) if isinstance(x, list) else x
    # )
    # I should probably follow that pattern if the original file uses JSON strings.
    # Let's check if the input used JSON strings.
    # Actually, parse_aliases handles both.
    # To be safe and consistent with remove_alias.py:
    
    df_result['aliases'] = df_result['aliases'].apply(
        lambda x: json.dumps(x) if isinstance(x, list) else x
    )
    
    df_result.to_parquet(output_path, index=False)
    print("Done!")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

