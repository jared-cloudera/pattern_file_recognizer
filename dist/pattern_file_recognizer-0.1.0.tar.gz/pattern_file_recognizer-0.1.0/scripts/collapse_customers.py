#!/usr/bin/env python3
"""
Utility script to collapse multiple customer records into single records.

This script uses a YAML configuration file to define collapse rules. Each rule
specifies a regex pattern and a target customer name. Any customer whose NAME
matches the pattern will be consolidated into the target customer.

IMPORTANT: Only customer NAMES are matched, not aliases. This ensures idempotency.

Pattern matching uses re.fullmatch(), meaning the pattern must match the ENTIRE
string, not just a prefix or substring. Anchors (^ and $) are implicit.

YAML Configuration Format:
    collapses:
      - pattern: ".*IBM ANALYTICS"      # Matches "IBM ANALYTICS", "3M IBM ANALYTICS", etc.
        name: "IBM"
      - pattern: "IBM\\s+.*"            # Matches "IBM ANALYTICS", but NOT "3M IBM ANALYTICS"
        name: "IBM"
      - pattern: "ACCENTURE.*"          # Matches anything starting with "ACCENTURE"
        name: "ACCENTURE PUBLIC LIMITED COMPANY"

Usage:
    python scripts/collapse_customers.py config.yaml
    python scripts/collapse_customers.py config.yaml --output collapsed_customers.parquet
    python scripts/collapse_customers.py config.yaml --dry-run
"""

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd
import yaml


def parse_aliases(aliases_value) -> list[str]:
    """
    Parse aliases from the dataframe cell.
    
    Handles both Python lists and JSON strings.
    """
    # Check if it's already a list first (before pd.isna which fails on lists)
    if isinstance(aliases_value, list):
        return aliases_value
    
    if pd.isna(aliases_value):
        return []
    
    if isinstance(aliases_value, str):
        try:
            aliases_list = json.loads(aliases_value)
            if isinstance(aliases_list, list):
                return aliases_list
        except json.JSONDecodeError:
            pass
    
    return []


def customer_matches_pattern(customer_name: str, pattern: re.Pattern) -> bool:
    """
    Check if a customer name matches a pattern.
    
    Only checks the customer's primary name, not aliases. This ensures that
    collapse operations are idempotent - once a customer is collapsed and
    becomes an alias, it won't be matched again in subsequent rules.
    
    Args:
        customer_name: The customer's name
        pattern: Compiled regex pattern
        
    Returns:
        True if the customer name matches the pattern (full string match)
    """
    return pattern.fullmatch(customer_name) is not None


def collapse_customers(
    df: pd.DataFrame,
    collapse_rules: list[dict],
    dry_run: bool = False
) -> tuple[pd.DataFrame, dict]:
    """
    Collapse customer records based on pattern matching rules.
    
    Args:
        df: DataFrame with customer data
        collapse_rules: List of dicts with 'pattern' and 'name' keys
        dry_run: If True, only report what would be changed without modifying data
        
    Returns:
        Tuple of (modified_dataframe, statistics_dict)
    """
    stats = {
        'total_rules': len(collapse_rules),
        'rules_applied': [],
        'total_collapsed': 0,
        'total_aliases_added': 0
    }
    
    # Work with a copy to avoid modifying original
    df = df.copy()
    
    # Track indices to remove
    indices_to_remove = set()
    
    for rule_idx, rule in enumerate(collapse_rules, 1):
        pattern_str = rule['pattern']
        target_name = rule['name']
        
        print(f"\n[Rule {rule_idx}/{len(collapse_rules)}] Pattern: '{pattern_str}' -> Target: '{target_name}'")
        
        # Compile regex pattern
        try:
            pattern = re.compile(pattern_str)
        except re.error as e:
            print(f"  ERROR: Invalid regex pattern: {e}")
            continue
        
        # Find target customer
        target_mask = df['name'] == target_name
        if not target_mask.any():
            print(f"  WARNING: Target customer '{target_name}' not found. Skipping rule.")
            continue
        
        target_idx = df[target_mask].index[0]
        target_aliases = parse_aliases(df.at[target_idx, 'aliases'])
        target_aliases_set = set(target_aliases)
        
        # Find all matching customers (excluding target)
        matching_indices = []
        for idx, row in df.iterrows():
            if idx == target_idx:
                continue  # Skip the target itself
            if idx in indices_to_remove:
                continue  # Skip already removed customers
            
            customer_name = row['name']
            if pd.isna(customer_name):
                continue
            
            if customer_matches_pattern(customer_name, pattern):
                matching_indices.append(idx)
        
        if not matching_indices:
            print(f"  No matching customers found.")
            continue
        
        print(f"  Found {len(matching_indices)} matching customer(s):")
        
        # Collect all aliases from matching customers
        new_aliases = []
        for idx in matching_indices:
            customer_name = df.at[idx, 'name']
            customer_aliases = parse_aliases(df.at[idx, 'aliases'])
            
            print(f"    - {customer_name} ({len(customer_aliases)} aliases)")
            
            # Add the customer's name as an alias (if different from target)
            if customer_name != target_name and customer_name not in target_aliases_set:
                new_aliases.append(customer_name)
                target_aliases_set.add(customer_name)
            
            # Add all customer's aliases
            for alias in customer_aliases:
                if alias and alias not in target_aliases_set:
                    new_aliases.append(alias)
                    target_aliases_set.add(alias)
        
        # Update target customer with new aliases
        if new_aliases:
            updated_aliases = target_aliases + new_aliases
            if not dry_run:
                df.at[target_idx, 'aliases'] = updated_aliases
            print(f"  Added {len(new_aliases)} new alias(es) to '{target_name}'")
        
        # Mark matching customers for removal
        if not dry_run:
            indices_to_remove.update(matching_indices)
        
        # Update statistics
        stats['rules_applied'].append({
            'pattern': pattern_str,
            'target': target_name,
            'collapsed_count': len(matching_indices),
            'aliases_added': len(new_aliases)
        })
        stats['total_collapsed'] += len(matching_indices)
        stats['total_aliases_added'] += len(new_aliases)
    
    # Remove collapsed customers
    if indices_to_remove and not dry_run:
        print(f"\nRemoving {len(indices_to_remove)} collapsed customer record(s)...")
        df = df.drop(indices_to_remove)
        df = df.reset_index(drop=True)
    
    return df, stats


def load_config(config_path: Path) -> dict:
    """Load and validate YAML configuration file."""
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    if not config or 'collapses' not in config:
        raise ValueError("Configuration must contain 'collapses' key with a list of rules")
    
    if not isinstance(config['collapses'], list):
        raise ValueError("'collapses' must be a list")
    
    for rule in config['collapses']:
        if 'pattern' not in rule or 'name' not in rule:
            raise ValueError("Each collapse rule must have 'pattern' and 'name' keys")
    
    return config


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Collapse customer records based on YAML configuration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example YAML configuration (patterns use full-string matching):
  collapses:
    - pattern: ".*IBM ANALYTICS"      # Matches any string ending with "IBM ANALYTICS"
      name: "IBM"
    - pattern: "IBM\\s+.*"            # Matches strings starting with "IBM " (space after)
      name: "IBM"
    - pattern: "ACCENTURE.*"          # Matches any string starting with "ACCENTURE"
      name: "ACCENTURE PUBLIC LIMITED COMPANY"

Examples:
  %(prog)s config.yaml
  %(prog)s config.yaml --output collapsed_customers.parquet
  %(prog)s config.yaml --dry-run
        """
    )
    parser.add_argument(
        "config",
        type=Path,
        help="Path to YAML configuration file"
    )
    parser.add_argument(
        "--input",
        type=Path,
        help="Path to input customers.parquet file (default: auto-detect)"
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Path to output parquet file (default: customers_collapsed.parquet in CWD)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be changed without modifying data"
    )
    
    args = parser.parse_args()
    
    # Determine input path
    if args.input:
        input_path = args.input
    else:
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        input_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    if not input_path.exists():
        print(f"Error: Input file not found at {input_path}", file=sys.stderr)
        return 1
    
    # Determine output path
    if args.output:
        output_path = args.output
    else:
        output_path = Path.cwd() / "customers_collapsed.parquet"
    
    # Load configuration
    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error loading configuration: {e}", file=sys.stderr)
        return 1
    
    print(f"Loading customer data from: {input_path}")
    df = pd.read_parquet(input_path)
    print(f"Loaded {len(df)} customer records")
    
    if args.dry_run:
        print("\n=== DRY RUN MODE - No changes will be made ===")
    
    # Apply collapse rules
    df_result, stats = collapse_customers(df, config['collapses'], dry_run=args.dry_run)
    
    # Print summary
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"Total rules processed: {stats['total_rules']}")
    print(f"Total customers collapsed: {stats['total_collapsed']}")
    print(f"Total aliases added: {stats['total_aliases_added']}")
    print(f"Original customer count: {len(df)}")
    print(f"Final customer count: {len(df_result)}")
    print(f"Net reduction: {len(df) - len(df_result)} records")
    
    if args.dry_run:
        print("\n=== DRY RUN COMPLETE - No files written ===")
        return 0
    
    # Save result
    print(f"\nSaving collapsed data to: {output_path}")
    
    # Convert aliases lists to JSON strings for parquet compatibility
    df_result['aliases'] = df_result['aliases'].apply(
        lambda x: json.dumps(x) if isinstance(x, list) else x
    )
    
    df_result.to_parquet(output_path, index=False)
    print("Done!")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

