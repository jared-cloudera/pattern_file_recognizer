#!/usr/bin/env python3
"""
Utility script to lookup customers by alias.

This script takes an alias as input and returns all customer names that have
that alias in their aliases list.

Usage:
    python scripts/lookup_alias.py "IBM"
    python scripts/lookup_alias.py "Accenture" --case-sensitive
"""

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


def parse_aliases(aliases_value) -> list[str]:
    """
    Parse aliases from the dataframe cell.
    
    Handles both Python lists and JSON strings.
    """
    if pd.isna(aliases_value):
        return []
    
    if isinstance(aliases_value, list):
        return aliases_value
    
    if isinstance(aliases_value, str):
        try:
            aliases_list = json.loads(aliases_value)
            if isinstance(aliases_list, list):
                return aliases_list
        except json.JSONDecodeError:
            pass
    
    return []


def find_customers_by_alias(
    df: pd.DataFrame, 
    target_alias: str, 
    case_sensitive: bool = False
) -> list[str]:
    """
    Find all customer names that have the specified alias.
    
    Args:
        df: DataFrame with 'name' and 'aliases' columns
        target_alias: The alias to search for
        case_sensitive: Whether to perform case-sensitive matching
        
    Returns:
        List of customer names that have the specified alias
    """
    matching_customers = []
    
    # Normalize target alias if case-insensitive
    search_alias = target_alias if case_sensitive else target_alias.lower()
    
    for _, row in df.iterrows():
        customer_name = row.get('name')
        if pd.isna(customer_name):
            continue
            
        aliases = parse_aliases(row.get('aliases'))
        
        # Check if target alias is in this customer's aliases
        for alias in aliases:
            compare_alias = alias if case_sensitive else alias.lower()
            if compare_alias == search_alias:
                matching_customers.append(customer_name)
                break  # Found a match, no need to check other aliases
    
    return matching_customers


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Lookup customers by alias",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "IBM"
  %(prog)s "Accenture" --case-sensitive
  %(prog)s "VOD"
        """
    )
    parser.add_argument(
        "alias",
        help="The alias to search for"
    )
    parser.add_argument(
        "--case-sensitive",
        action="store_true",
        help="Perform case-sensitive matching (default: case-insensitive)"
    )
    parser.add_argument(
        "--parquet-path",
        type=Path,
        help="Path to customers.parquet file (default: auto-detect from script location)"
    )
    
    args = parser.parse_args()
    
    # Determine the parquet file path
    if args.parquet_path:
        parquet_path = args.parquet_path
    else:
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        parquet_path = project_root / "src" / "customer_recognizer" / "data" / "customers.parquet"
    
    if not parquet_path.exists():
        print(f"Error: Customer data not found at {parquet_path}", file=sys.stderr)
        return 1
    
    # Load data
    df = pd.read_parquet(parquet_path)
    
    # Find matching customers
    matching_customers = find_customers_by_alias(
        df, 
        args.alias, 
        case_sensitive=args.case_sensitive
    )
    
    # Display results
    if matching_customers:
        print(f"Found {len(matching_customers)} customer(s) with alias '{args.alias}':\n")
        for customer in sorted(matching_customers):
            print(f"  - {customer}")
    else:
        print(f"No customers found with alias '{args.alias}'")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

