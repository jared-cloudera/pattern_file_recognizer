# Pseudonymization Operator Implementation Plan

## Overview

We will implement a custom Presidio Anonymizer operator that replaces recognized customer entities with a consistent pseudonym. The pseudonyms will be generated using `coolname` and stored in `customers.parquet` to ensure consistency across runs.

## Architecture

- **Operator Class**: `CustomerPseudonymizer` in `src/customer_recognizer/operators.py`.
- **Data Storage**: Updates `src/customer_recognizer/data/customers.parquet` with a new `pseudonym` column.
- **Concurrency**: Uses `fcntl` for file locking to safely handle concurrent updates to the parquet file.
- **Generation Strategy**: `coolname` (3 words, capitalized, hyphenated).

## Steps

### 1. Setup Documentation

- Create `docs` directory.
- Store this plan in `docs/plan-pseudonymization.md`.

### 2. Implement Operator Logic

- Create [`src/customer_recognizer/operators.py`](src/customer_recognizer/operators.py).
- **Class**: `CustomerPseudonymizer`
- **Method**: `operate(text: str, params: Dict = None) -> str`
- **Logic**:

    1.  Acquire exclusive lock on `customers.parquet.lock`.
    2.  Read `customers.parquet`.
    3.  Ensure `pseudonym` column exists.
    4.  Search for `text` in `name` or `aliases` (parsed from JSON).
    5.  Handle matches:

        - No match: Generate new pseudonym? (Requirements say "scan ... for the recognized entity", implies it must exist in DB. If not found, we might treat it as a new entry or just return original. Requirement says "If the pseudonym column value is present, use that value. If there is no pseudonym yet, use the `coolname` library". This implies the row must be found. If not found, we probably shouldn't pseudonymize or should generate a transient one. We will assume for now we only anonymize known customers).
        - Multiple matches: Log warning, pick first.

    1.  If `pseudonym` is empty/null, generate using `coolname`.
    2.  Update DataFrame and write back to Parquet.
    3.  Release lock.
    4.  Return pseudonym.

### 3. Expose Operator

- Update [`src/customer_recognizer/__init__.py`](src/customer_recognizer/__init__.py) to export `CustomerPseudonymizer`.

### 4. Testing

- Create [`tests/test_operators.py`](tests/test_operators.py).
- Test cases:
    - Existing pseudonym retrieval.
    - New pseudonym generation and persistence.
    - Multiple match handling.
    - Locking mechanism (mocked).
    - Data persistence verification.

## Questions Resolved

- **Concurrency**: Using `fcntl` (POSIX) for file locking as requested ("simple but functional").




