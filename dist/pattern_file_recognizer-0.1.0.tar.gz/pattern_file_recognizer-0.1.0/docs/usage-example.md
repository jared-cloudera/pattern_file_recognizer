# Customer Anonymization Usage Examples

This document demonstrates how to anonymize customer names in text using the `customer_recognizer` package.

## Quick Start (Recommended)

The simplest way to anonymize customer names is using the `CustomerAnonymizerService` facade:

```python
from customer_recognizer import CustomerAnonymizerService

# Initialize the service
service = CustomerAnonymizerService()

# Sample text containing customer names
text = "We are working with 10 CREATIVE SOLUTIONS and ACME Corp on this project."

# Anonymize the text
anonymized = service.anonymize(text)

print(f"Original: {text}")
print(f"Anonymized: {anonymized}")
```

### Expected Output

```
Original: We are working with 10 CREATIVE SOLUTIONS and ACME Corp on this project.
Anonymized: We are working with Cust-Mighty-Falcon-Of-Glory and Cust-Clever-Badger-Of-Wisdom on this project.
```

### Adding Custom Customer Names

You can also add additional customer names that aren't in the bundled database:

```python
service = CustomerAnonymizerService(additional_names=["MyCustomer Inc", "Secret Corp"])
anonymized = service.anonymize("MyCustomer Inc is our partner.")
```

## Advanced Usage (Direct API)

For users who need more control over the Presidio engines or want to integrate with existing Presidio pipelines, you can use the underlying components directly:

```python
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
from customer_recognizer import CustomerRecognizer, CustomerPseudonymizer

# Initialize the analyzer with the custom recognizer
analyzer = AnalyzerEngine()
recognizer = CustomerRecognizer()
analyzer.registry.add_recognizer(recognizer)

# Initialize the anonymizer
anonymizer = AnonymizerEngine()

# Sample text containing customer names
text = "We are working with 10 CREATIVE SOLUTIONS and ACME Corp on this project."

# Analyze the text to find customer entities
analyzer_results = analyzer.analyze(text=text, language="en")

# Configure the anonymizer to use the custom pseudonymizer for CUSTOMER_ORG entities
operators = {
    "CUSTOMER_ORG": OperatorConfig("custom", {"lambda": CustomerPseudonymizer().operate})
}

# Anonymize the text
anonymized_result = anonymizer.anonymize(
    text=text,
    analyzer_results=analyzer_results,
    operators=operators
)

print(f"Original: {text}")
print(f"Anonymized: {anonymized_result.text}")
```

The output will be the same as the Quick Start example above.

## Features

- **Consistent Pseudonyms**: The same customer name will always get the same pseudonym across multiple runs
- **Persistent Storage**: Pseudonyms are stored in the `customers.parquet` file
- **Thread-Safe**: Uses file locking to ensure safe concurrent access
- **Alias Support**: Matches customer names and their aliases
- **Case-Insensitive**: Matching is case-insensitive for better coverage

## Notes

- Unknown customer names (not in the database) will be returned unchanged
- Multiple matches will trigger a warning and use the first match
- Pseudonyms are generated using the `coolname` library with 3+ words

